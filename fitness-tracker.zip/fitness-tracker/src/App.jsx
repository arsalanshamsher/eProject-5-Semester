import React from "react";
import AppRoutes from "./router";

export default function App() {
  return <AppRoutes />;
}
